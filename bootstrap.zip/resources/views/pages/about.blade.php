@extends('layouts.app')

@section('content')
<h1>About</h1>
<p>This is about page.</p>
@endsection
